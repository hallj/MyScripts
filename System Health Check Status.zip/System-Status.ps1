<#
.SYNOPSIS
	Checks various components of the system and returns the results

.DESCRIPTION
	Checks various components of the system and returns the results
	- Network Connectivity Test 
	- Internet Connectivity Test 
	- OS Info 
	- System Up Time 
	- OS Patch History 
	- Memory Info 
	- CPU Info 
	- Network Info 
	- Disk Info 
	- Running Processes 
	- Running Services 

.PARAMETER Computers
        List of computers to check
		Default value is local computer

.PARAMETER Services
		List of services to check
		
.PARAMETER Customer
		Customer Name

.PARAMETER Outfile
		Path and file name of Location to save results
		Default value is C:\temp\SystemStatusReport.htm
		
.PARAMETER To
		List of mail recipients to send results to
		
.PARAMETER From
		Sender address
		Default value is local system
	
.PARAMETER Smtp
		FQDN of SMTP Server

.PARAMETER
    <CommonParameters>
        This cmdlet supports the common parameters: Verbose, Debug,
        ErrorAction, ErrorVariable, WarningAction, WarningVariable,
        OutBuffer, PipelineVariable, and OutVariable. For more information, see
        about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

.EXAMPLE
	C:\PS>Test-Connection computer1
		Checks is a remote connection can be made to the specified computer
.EXAMPLE		
	C:\PS>Get-OSInfo computer1
		Gets basic information of the remote host's operating system
.EXAMPLE	
	C:\PS> Get-Uptime computer1
		Gets system up time synce last boot from the specified computer
.EXAMPLE	
	C:\PS>Get-Patches computer1
		Gets the last 25 patches installed on the specified computer
.EXAMPLE	
	C:\PS>Get-Patches -computer computer1 -LastPatchDate:$True
		get the most current date that a patch was installed from the specified computer
.EXAMPLE	
	C:\PS>Get-MemoryInfo computer1
		Gets basic memmory (RAM) information from the computer specified
.EXAMPLE	
	C:\PS>Get-ProcessorInfo conmputer1
		Gets baic information of all the processors (CPUs) configured for the specified computer
.EXAMPLE	
	C:\PS>Get-NetworkInfo
		Gets basic information from the enabled network interfaces for hte specified computer
.EXAMPLE	
	C:\PS>Get-CPUTemperature computer1
		Gets the current temperatures of the configured CPUs for the specified computer
.EXAMPLE	
	C:\PS>Get-ProcessInfo computer1
		Gets a list of running processes for the specified computer
.EXAMPLE		
	C:\PS>Get-ServiceStatus computer1
		Gets the status of services who's startup mode is either Automatic or Manual for the specified computer
.EXAMPLE	
	C:\PS>Get-DiskSpace computer1
		Gets the disk space stats for all local drives for the specified computer
.EXAMPLE	
	C:\PS>Start-Checks computer1,computer2
		Runs all of hte checks for the speficied computers
.EXAMPLE	
	C:\PS>Start-Checks computer1,computer2 -To user1@domain.com -SMTP SMTP-FQDN.domain.com
		Runs all of hte checks for the speficied computers then sends an email with the results to the speficied users using the specified SMTP server
.EXAMPLE
	-Noninteractive -Noprofile Start-Checks -To user@domain.com -From $("$env:ComputerName@domain.com") -SMTP smtp-server.domain.com
		Use the above string as the action for a scheduled task

.INPUTS
    System.String
	System.Object

.OUTPUTS
    System.String
	System.Management.ManagementObject
	System.__ComObject
	System.DateTime
	System.IO.FileInfo
	System.Net.Mail.MailMessage
	System.Net.Mail.Attachment

.NOTES

	Script Name:	System-Status.psm1
	Version:		0.1
	Created By:		Jon Hall
	Date Created:	August 10, 2017
	Date Modified:	
	Updates:		
	Requirements:	Powershell Version 2.0 or greater
					Powershell Version 3.0 or greater to take advantage of Get-CimInstance
	
	Other:			Module is placed in C:\Windows\system32\WindowsPowerShell\v1.0\Modules\
					so the functions will load automatically
					
					Basic terminology
					CIM:	Common Information Model (CIM) is the DMTF standard [DSP0004] for describing the 
							structure and behavior of managed resources such as storage, network, or software components.

					WMI:	Windows Management Instrumentation (WMI) is a CIM server that implements the CIM standard on Windows.

					WS-Man:	WS-Management (WS-Man) protocol is a SOAP-based, firewall-friendly protocol for management 
							clients to communicate with CIM servers.

					WinRM:	Windows Remote Management (WinRM) is the Microsoft implementation of the WS-Man protocol on Windows.
					
	CIM Classes:	Common Information Model (CIM)
					CIM classes are equivalent WMI classes.
					The CIM schema contains the definitions for the core and common classes.
					The Win32 schema contains the definitions for the extended classes that are common to the Win32 environment.
	
					https://msdn.microsoft.com/en-us/library/aa389234(v=vs.85).aspx
					Computer System:	https://msdn.microsoft.com/en-us/library/aa394102(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa387219(v=vs.85).aspx
					
					Operating System:	https://msdn.microsoft.com/en-us/library/aa394239(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa387937(v=vs.85).aspx
					
					Processor:			https://msdn.microsoft.com/en-us/library/aa394373(v=vs.85).aspx
					
					Physical Memory:	https://msdn.microsoft.com/en-us/library/aa394347(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa387968(v=vs.85).aspx
					
					Disk Drive:			https://msdn.microsoft.com/en-us/library/aa394132(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa387254(v=vs.85).aspx
					
					Logical Disk:		https://msdn.microsoft.com/en-us/library/aa394173(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa387886(v=vs.85).aspx
					
					Disk Partition:		https://msdn.microsoft.com/en-us/library/aa394135(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa387256(v=vs.85).aspx
					
					File System:		
										https://msdn.microsoft.com/en-us/library/aa387256(v=vs.85).aspx
					
					Logical Disk:		https://msdn.microsoft.com/en-us/library/aa394173(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa387886(v=vs.85).aspx
					
					SCSI Controller:	https://msdn.microsoft.com/en-us/library/aa394400(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa388437(v=vs.85).aspx				
					
					Network Adapter:	https://msdn.microsoft.com/en-us/library/aa394217(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa387931(v=vs.85).aspx
										
					Service:			https://msdn.microsoft.com/en-us/library/aa394418(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/library/aa388442(v=vs.85).aspx
					
					Process:			https://msdn.microsoft.com/en-us/library/aa394372(v=vs.85).aspx
										https://msdn.microsoft.com/en-us/windows/aa394277(v=vs.90).aspx
										
.LINK
about_Modules

#>

param(
	[string[]]$Computers = "$env:ComputerName.$env:UserDNSDomain",
	[string]$Outfile = "c:\temp\SystemStatusReport.htm",
	[string[]]$To,
	[string]$From = "$env:ComputerName@domain.com",
	[string]$SMTP,
	[int]$Days = 30,
	[int]$TopXProcesses = 10,
	[string]$log = "C:\bin\debug.log"
)

$DefaultVariables='';new-variable -name DefaultVariables -value (Get-Variable | % {$_.Name}) -force
#region User Functions
Function Test-OutputFile
{
	param($Outfile)

	Out-Console -Type 1 -Message "Checking existence of $($outfile.SubString(0,$outfile.LastIndexOf('\')))"
	#Check if output path exists. If not, create it.
	If(!(Test-Path $outfile.SubString(0,$outfile.LastIndexOf('\'))))
	{
		Try
		{
			New-Item -ItemType Directory -Force -Path $outfile.SubString(0,$outfile.LastIndexOf('\'))
			Out-Console -Type 1 -Message "$($outfile.SubString(0,$outfile.LastIndexOf('\'))) created successfully"
		}
		Catch
		{
			Out-Console -Type 0 -Message "Unable to create $($outfile.SubString(0,$outfile.LastIndexOf('\'))) - $($_.Exception.Message)"
		}
	}
	Out-Console -Type 1 -Message "Checking existence of $($outfile.SubString($outfile.LastIndexOf('\')+1,$Outfile.length-$outfile.LastIndexOf('\')-1))"
	#Check if output file exists. If it does, remove it
	If (Test-Path $Outfile)
	{
		Try
		{
			#Remove-Item $Outfile -Force
			$file = Get-Item $Outfile
			$file.Delete()
			Out-Console -Type 1 -Message "$($outfile.SubString($outfile.LastIndexOf('\')+1,$Outfile.length-$outfile.LastIndexOf('\')-1)) deleted successfully"
		}
		Catch
		{
			Out-Console -Type 0 -Message "Unable to delete $($outfile.SubString($outfile.LastIndexOf('\')+1,$Outfile.length-$outfile.LastIndexOf('\')-1)) - $($_.Exception.Message)"
		}
	}
}
	
Function Test-Connectivity
{
	param([string]$Computer)
	
	Try
	{
		Out-Console -Type 1 -Message "Testing connectivity to $Computer"
		$test = Test-Connection -ComputerName $Computer -Quiet
		If ($test)
		{
			Out-Console -Type 1 -Message "successfully connected to $Computer"
		}
		Else
		{
			Out-Console -Type 2 -Message "unable to connected to $Computer"
		}
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to connect to $Computer - $($_.Exception.Message)"
	}
	Return $test
}

Function Get-SystemInfo
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	$Properties = @{n='CPUs';e={$_.NumberOfProcessors}},`
		@{n='Logical CPUs';e={$_.NumberOfLogicalProcessors}},`
		@{n='Memory (GB)';e={[int]("{0:N0}" -f ($_.TotalPhysicalMemory / 1GB))}},`
				@{n='Role';e={
			Switch ($_.DomainRole)
			{
				0 {'Standalone Workstation'}
				1 {'Member Workstation'}
				2 {'Standalone Server'}
				3 {'Member Server'}
				4 {'Backup Domain Controller'}
				5 {'Primary Domain Controller'}
			}}},`
		"Status",`
		@{n='Bootup State';e={$_.BootupState}},`
		@{n='Chassis State';e={
			Switch ($_.ChassisBootupState)
			{
				1 {'Other'}
				2 {'Unknown'}
				3 {'Safe'}
				4 {'Warning'}
				5 {'Critical'}
				6 {'Non-recoverable'}
			}}},`
		@{n='Power State';e={
			Switch ($_.PowerState)
			{
				0 {'Unknown'}
				1 {'Full Power'}
				2 {'Power Save - Low Power Mode'}
				3 {'Power Save - Standby'}
				4 {'Power Save - Unknown'}
				5 {'Power Cycle'}
				6 {'Power Off'}
				7 {'Power Save - Warning'}
				8 {'Power Save - Hibernate'}
				9 {'Power Save - Soft Off'}
			}}},`
		@{n='Power Supply State';e={
			Switch ($_.PowerSupplyState)
			{
				1 {'Other'}
				2 {'Unknown'}
				3 {'Safe'}
				4 {'Warning'}
				5 {'Critical'}
				6 {'Non-recoverable'}
			}}},`
		@{n='Temperature State';e={
			Switch ($_.ThermalState)
			{
				1 {'Other'}
				2 {'Unknown'}
				3 {'Safe'}
				4 {'Warning'}
				5 {'Critical'}
				6 {'Non-recoverable'}
			}}},`
		@{n='Wakeup Type';e={
			Switch ($_.WakeupType)
			{
				0 {'Reserved'}
				1 {'Other'}
				2 {'Unknown'}
				3 {'APM Timer'}
				4 {'Modem Ring'}
				5 {'LAN Remote'}
				6 {'Power Switch'}
				7 {'PCI PME#'}
				8 {'AC Power Restored'}
			}}},`
		@{n='Admin Password';e={
			Switch ($_.AdminPasswordStatus)
			{
				0 {'Disabled'}
				1 {'Enabled'}
				2 {'Not Implemented'}
				3 {'Unknown'}
			}}},`
		"Manufacturer",`
		"Model",`
		"SystemFamily",`
				@{n='System Type';e={
			Switch ($_.PCSystemTypeEx)
			{
				0 {'Unspecified'}
				1 {'Desktop'}
				2 {'Mobile'}
				3 {'Workstation'}
				4 {'Enterprise Server'}
				5 {'Small Office and Home Office (SOHO) Server'}
				6 {'Appliance PC'}
				7 {'Performance Server'}
				8 {'Slate'}
				9 {'Maximum'}
			}}}
		
	Try
	{
		Out-Console -Type 1 -Message "Gathering computer information for $Computer"
		
		If ($PSVersionTable.PSVersion.Major -ge 3)
			{Get-CimInstance -ComputerName $Computer Cim_ComputerSystem | Select $Properties}
		ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
			{Get-WMIObject -ComputerName $Computer Cim_ComputerSystem | Select $Properties}
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get computer information $Computer - $($_.Exception.Message)"
	}
}
	
Function Get-OSInfo
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	$Properties = @{n="Operating System";e={$_.Caption}},`
		@{n='Service Pack';e={$_.ServicePackMajorVersion}},`
		"Version",`
		@{n="Build";e={$_.BuildNumber}},`
		@{n='Boot Device';e={$_.BootDevice}},`
		@{n='System Device';e={$_.SystemDevice}},`
		@{n="System Directory";e={$_.SystemDirectory}},`
		@{n="Last Boot Up Time";e={$_.LastBootUpTime}},`
		@{n="Up Time";e={Get-Uptime $Computer}},`
		@{n="Last PatchDate";e={Get-LastPatchDate $Computer}},`
		@{n='FreePhysicalMemory (GB)';e={[int]("{0:N0}" -f ($_.FreePhysicalMemory / 1MB))}},`
		@{n='FreeSpaceInPagingFiles (GB)';e={[int]("{0:N0}" -f ($_.FreeSpaceInPagingFiles / 1MB))}},`
		@{n='FreeVirtualMemory (GB)';e={[int]("{0:N0}" -f ($_.FreeVirtualMemory / 1MB))}}
		
	Try
	{
		Out-Console -Type 1 -Message "Gathering operating system information for $Computer"
		If ($PSVersionTable.PSVersion.Major -ge 3)
			{Get-Ciminstance -ComputerName $Computer CIM_OperatingSystem | Select $Properties}
		ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
			{Get-WMIObject -ComputerName $Computer CIM_OperatingSystem | Select $Properties}
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get operating system information for $Computer - $($_.Exception.Message)"
	}
}

Function Get-ProcessorInfo
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	$Properties = @{n="ID";e={$_.DeviceID}},`
		"Name",`
		"Status",`
		@{n='CPU Status';e={
			Switch ($_.CPUStatus)
			{
				0 {'Unknown'}
				1 {'CPU Enabled'}
				2 {'CPU Disabled by User via BIOS Setup'}
				3 {'CPU Disabled By BIOS (POST Error)'}
				4 {'CPU is Idle'}
				5 {'Reserved'}
				6 {'Reserved'}
				7 {'Other'}
			}}},`
		@{n="Max Clock Speed (MHz)";e={$_.MaxClockSpeed}},`
		@{n="Current Clock Speed (MHz)";e={$_.CurrentClockSpeed}},`
		@{n="Cores";e={[int]($_.NumberOfCores)}},`
		@{n="Logical Processors";e={[int]($_.NumberOfLogicalProcessors)}},`
		@{n="% load";e={[int]($_.loadpercentage)}},`
		@{n='Availability';e={
		Switch ($_.Availability)
		{
			1 {'Other'}
			2 {'Unknown'}
			3 {'Running/Full Power'}
			4 {'Warning'}
			5 {'In Test'}
			6 {'Not Applicable'}
			7 {'Power Off'}
			8 {'Off Line'}
			9 {'Off Duty'}
			10 {'Degraded'}
			11 {'Not Installed'}
			12 {'Install Error'}
			13 {'Power Save - Unknown'}
			14 {'Power Save - Low Power Mode'}
			15 {'Power Save - Standby'}
			16 {'Power Cycle'}
			17 {'Power Save - Warning'}
			18 {'Paused'}
			19 {'Not Ready'}
			20 {'Not Configured'}
			21 {'Quiesced'}
		}}}
		
	Try
	{
		Out-Console -Type 1 -Message "Gathering processor information for $Computer"
		If ($PSVersionTable.PSVersion.Major -ge 3)
			{Get-Ciminstance -ComputerName $Computer Cim_processor | select $Properties}
		ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
			{Get-WMIObject -ComputerName $Computer Cim_processor | select $Properties}
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get processor information $Computer - $($_.Exception.Message)"
	}
	
}	

Function Get-CPUTemperature
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	Try
	{
		Out-Console -Type 1 -Message "Getting CPU temperature for $Computer"
		
		If ($PSVersionTable.PSVersion.Major -ge 3)
			{$t = Get-Ciminstance -ComputerName $Computer MSAcpi_ThermalZoneTemperature -Namespace "root/wmi"}
		ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
			{$t = Get-WMIObject -ComputerName $Computer MSAcpi_ThermalZoneTemperature -Namespace "root/wmi"}
			
		$returntemp = @()

		foreach ($temp in $t.CurrentTemperature)
		{

		$Kelvin = $temp / 10
		$Celsius = $Kelvin - 273.15
		$Fahrenheit = (9/5) * $Celsius + 32

		$returntemp += $Celsius.ToString() + "$([char]186) C : " + $Fahrenheit.ToString() + "$([char]186) F : " + $Kelvin + "$([char]186) K"  
		}
		
		$array = @(New-Object psobject -Property @{
			'Celsius' = [string]$Celsius + "$([char]186) C"
			'Fahrenheit' = [string]$Fahrenheit + "$([char]186) F"
			'Kelvin' = [string]$Kelvin + "$([char]186) K"
		})
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get CPU temperature for $Computer - $($_.Exception.Message)"
	}
	
	return $array | select Celsius,Fahrenheit,Kelvin
}

Function Get-MemoryInfo
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	$Properties = 
		@{n="Memory (GB)";e={[math]::round($_.TotalVisibleMemorySize / 1MB, 2)}},`
		@{n="Free Physical Memory (GB)";e={[math]::round($_.FreePhysicalMemory / 1MB, 2)}},`
		@{n="Free Space In Paging Files";e={[math]::round($_.FreeSpaceInPagingFiles / 1MB, 2)}},`
		@{n="Free Virtual Memory (GB)";e={[math]::round($_.FreeVirtualMemory / 1MB, 2)}},`
		@{n="Virtual Memory (GB)";e={[math]::round($_.TotalVirtualMemorySize / 1MB, 2)}}

		Try
		{
			Out-Console -Type 1 -Message "Gathering memory information for $Computer"
			If ($PSVersionTable.PSVersion.Major -ge 3)
				{Get-Ciminstance -ComputerName $Computer Cim_OperatingSystem | Select $Properties}
			ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
				{Get-WMIObject -ComputerName $Computer Cim_OperatingSystem | Select $Properties}
		}
		Catch
		{
			Out-Console -Type 0 -Message "Unable to get memory information for $Computer - $($_.Exception.Message)"
		}
}

Function Get-PhysicalMemoryInfo
{
	#param($Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	$Properties = "Name",`
		"DeviceLocator",`
		@{n='Capacity';e={$_.Capacity / 1GB}},`
		"Speed",`
		"TypeDetail",`
		@{n='Form Factor';e={
			Switch ($_.FormFactor)
			{
				0 {'Unknown'}
				1 {'Other'}
				2 {'SIP'}
				3 {'DIP'}
				4 {'ZIP'}
				5 {'SOJ'}
				6 {'Proprietary'}
				7 {'SIMM'}
				8 {'DIMM'}
				9 {'TSOP'}
				10 {'PGA'}
				11 {'RIMM'}
				12 {'SODIMM'}
				13 {'SRIMM'}
				14 {'SMD'}
				15 {'SSMP'}
				16 {'QFP'}
				17 {'TQFP'}
				18 {'SOIC'}
				19 {'LCC'}
				20 {'PLCC'}
				21 {'BGA'}
				22 {'FPBGA'}
				23 {'LGA'}
			}
		}},`
		@{n='Memory Type';e={
			Switch ($_.MemoryType)
			{
				0 {'Unknown'}
				1 {'Other'}
				2 {'DRAM'}
				3 {'Synchronous DRAM'}
				4 {'Cache DRAM'}
				5 {'EDO'}
				6 {'EDRAM'}
				7 {'VRAM'}
				8 {'SRAM'}
				9 {'RAM'}
				10 {'ROM'}
				11 {'Flash'}
				12 {'EEPROM'}
				13 {'FEPROM'}
				14 {'EPROM'}
				15 {'CDRAM'}
				16 {'3DRAM'}
				17 {'SDRAM'}
				18 {'SGRAM'}
				19 {'RDRAM'}
				20 {'DDR'}
				21 {'DDR2'}
				22 {'DDR2 FB-DIMM'}
			}
		}},`
		"PartNumber"
		
	Try
		{
			Out-Console -Type 1 -Message "Gathering physical memory information for $Computer"
			If ($PSVersionTable.PSVersion.Major -ge 3)
				{Get-CimInstance -ComputerName $Computer CIM_PhysicalMemory | select $Properties | Sort DeviceLocator}
			ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
				{Get-WMIObject -ComputerName $Computer CIM_PhysicalMemory | select $Properties | Sort DeviceLocator}
		}
		Catch
		{
			Out-Console -Type 0 -Message "Unable to get physical memory information for $Computer - $($_.Exception.Message)"
		}
}

Function Get-SCSIControllerInfo
{
	#param($Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	$Properties = "Name",`
	"Status",`
	@{n='Availability';e={
		Switch ($_.Availability)
		{
			1 {'Other'}
			2 {'Unknown'}
			3 {'Running/Full Power'}
			4 {'Warning'}
			5 {'In Test'}
			6 {'Not Applicable'}
			7 {'Power Off'}
			8 {'Off Line'}
			9 {'Off Duty'}
			10 {'Degraded'}
			11 {'Not Installed'}
			12 {'Install Error'}
			13 {'Power Save - Unknown'}
			14 {'Power Save - Low Power Mode'}
			15 {'Power Save - Standby'}
			16 {'Power Cycle'}
			17 {'Power Save - Warning'}
			18 {'Paused'}
			19 {'Not Ready'}
			20 {'Not Configured'}
			21 {'Quiesced'}
		}}},`
	@{n='StatusInfo';e={
		Switch ($_.StatusInfo)
		{
			1 {'Other'}
			2 {'Unknown'}
			3 {'Enabled'}
			4 {'Disabled'}
			5 {'Not Applicable'}
		}}},`
	"Manufacturer",`
	"DriverName"
	
	Try
		{
			Out-Console -Type 1 -Message "Gathering SCSI controller information for $Computer"
			If ($PSVersionTable.PSVersion.Major -ge 3)
				{Get-CimInstance -ComputerName $Computer CIM_SCSIController | select $Properties}
			ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
				{Get-WMIObject -ComputerName $Computer CIM_SCSIController | select $Properties}
		}
		Catch
		{
			Out-Console -Type 0 -Message "Unable to get SCSI controller information for $Computer - $($_.Exception.Message)"
		}
}

Function Get-DiskInfo
{
	#param($Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	$Properties = "DeviceID",`
		"Status",`
		@{n='SCSI Address';e={$('Port: ' + $_.SCSIPort + ' Bus: ' + $_.SCSIBus + ' Target: ' + $_.SCSITargetID + ' LUN: ' + $_.SCSILogicalUnit)}},`
		@{n='Size (GB)';e={[int]("{0:N0}" -f $($_.Size / 1GB))}},`
		"InterfaceType",`
		"Manufacturer",`
		"Model",`
		"FirmwareRevision"

	Try
	{
		Out-Console -Type 1 -Message "Gathering Disk information for $Computer"
		If ($PSVersionTable.PSVersion.Major -ge 3)
			{Get-CimInstance -ComputerName $Computer Cim_DiskDrive | Select $Properties}
		ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
			{Get-WMIObject -ComputerName $Computer Cim_DiskDrive | Select $Properties}
	}	
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get Disk information for $Computer - $($_.Exception.Message)"
	}		
}

Function Get-DiskSpace
{
	param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	#param([string]$Computer)
	
	Try
	{
		Out-Console -Type 1 -Message "Gathering Disk space information for $Computer"
		$script:j = 1
		$fragments = $Array = @() 
		
		
		$Drives = Get-WMIObject -ComputerName $Computer Cim_logicaldisk | ?{$_.drivetype  -eq 3}
	
		ForEach ($Drive in $Drives)
		{
			$Used = (($Drive.size - $Drive.FreeSpace)/$Drive.Size * 100)
			$Array += @(New-Object psobject -Property @{
				'HostName' = $Drive.SystemName
				'ID' = $Drive.DeviceID
				'Label' = $Drive.VolumeName
				'Size (GB)' = [int]("{0:N2}" -f ($Drive.Size / 1gb -as [int]))
				'Used (GB)' = [int]("{0:N2}" -f (($Drive.Size - $_.Freespace)/1GB))
				'Free (GB)' = [int]("{0:N2}" -f ($Drive.FreeSpace/1GB))
				'% Used' = [int]($Used.ToString('0.00'))
				'% Free' = [int]((($Drive.Freespace/$Drive.Size)*100).ToString('0.00'))
				'Usage' =	Add-Gradient $Used
			})
		}

		$frag = $Array | select ID,Label,'Size (GB)','Used (GB)','Free (GB)','% Used','% Free',@{n='Usage';e={$_.Usage | out-string}} | ConvertTo-HTML -Fragment -Pre "<br><H3>Disk Space</H3>"
		$frag = $frag -replace '&lt;','<' -Replace '&gt;','>' -replace '&#39',"'" -replace ';',''
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get Disk space information for $Computer - $($_.Exception.Message)"
	}
	Return $frag
}

Function Get-NetworkInfo
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
		$Properties = "Description",`
			@{n="DHCP Enabled";e={$_.DHCPEnabled}},`
			@{n="DHCP Server";e={$_.DHCPServer}},`
			@{n="DNS Domain";e={$_.DNSDomain}},`
			@{n="Domain Search Order";e={$_.DNSDomainSuffixSearchOrder -split "`r`n" -join "<br>"}},`
			@{n="Server Search Order";e={$_.DNSServerSearchOrder -split "`r`n" -join "<br>"}},`
			@{n="IP Address";e={$_.IPAddress -Match '\d{1,3}(\.\d{1,3}){3}' -split "`r`n" -join "<br>"}},`
			@{n="Default Gateway";e={$_.DefaultIPGateway -Match '\d{1,3}(\.\d{1,3}){3}' -split "`r`n" -join "<br>"}},`
			@{n="IP Subnet";e={$_.IPSubnet -Match '\d{1,3}(\.\d{1,3}){3}' -split "`r`n" -join "<br>"}},`
			@{n="MAC Address";e={$_.MacAddress}}
	
	Try
	{
		Out-Console -Type 1 -Message "Gathering network adapter information for $Computer"
		If ($PSVersionTable.PSVersion.Major -ge 3)
			{Get-Ciminstance -ComputerName $Computer win32_NetworkAdapterConfiguration | ?{$_.IPEnabled -eq $True} | select $Properties}
		ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
			{Get-WMIObject -ComputerName $Computer win32_NetworkAdapterConfiguration | ?{$_.IPEnabled -eq $True} | select $Properties}
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get network adapter information for $Computer - $($_.Exception.Message)"
	}	

<#
$IPSettings = Get-Ciminstance -ComputerName $Computer win32_NetworkAdapterConfiguration | ?{$_.IPEnabled -eq $True}

$Properties = "Index",`
"Description",`
"DHCPEnabled",`
"DHCPLeaseObtained",`
"DHCPServer",`
"DHCPLeaseExpires",`
"DNSDomain",`
"DNSDomainSuffixSearchOrder",`
"DNSEnabledForWINSResolution",`
"DNSHostName",`
"DNSServerSearchOrder",`
"DomainDNSRegistrationEnabled",`
"FullDNSRegistrationEnabled",`
"IPAddress",`
"WINSEnableLMHostsLookup",`
"WINSHostLookupFile",`
"WINSPrimaryServer",`
"WINSScopeID",`
"WINSSecondaryServer",`
"DefaultIPGateway",`
"InterfaceIndex",`
"IPSubnet",`
"MACAddress",`
"ServiceName"

$Settings = Get-Ciminstance -ComputerName $Computer win32_NetworkAdapterConfiguration | select $Properties

$DHCPProperties = "DHCPEnabled",`
"DHCPLeaseObtained",`
"DHCPServer",`
"DHCPLeaseExpires"
Get-Ciminstance -ComputerName $Computer win32_NetworkAdapterConfiguration | select $DHCPProperties

$DNSProperties = "DNSDomain",`
"DNSDomainSuffixSearchOrder",`
"DNSEnabledForWINSResolution",`
"DNSHostName",`
"DNSServerSearchOrder"
Get-Ciminstance -ComputerName $Computer win32_NetworkAdapterConfiguration | select $DNSProperties

$IPProperties = "Index",`
"Description",`
@{n='IP Address';e={$_.IPAddress -Match '\d{1,3}(\.\d{1,3}){3}'}},`
@{n='Subnet';e={$_.IPSubnet -Match '\d{1,3}(\.\d{1,3}){3}'}},`
@{n='Gateway';e={$_.DefaultIPGateway -Match '\d{1,3}(\.\d{1,3}){3}'}},`
"MACAddress"
Get-Ciminstance -ComputerName $Computer win32_NetworkAdapterConfiguration | select $IPProperties | ?{$_."IP Address" -ne $False}


$WINSProperties = "Index",`
"Description",`
"WINSEnableLMHostsLookup",`
"WINSHostLookupFile",`
"WINSPrimaryServer",`
"WINSScopeID",`
"WINSSecondaryServer"
Get-Ciminstance -ComputerName $Computer win32_NetworkAdapterConfiguration | select $WINSProperties | ?{$_.WINSPrimaryServer -ne $Null}

$Properties = "Index",`
"Description",`
"InterfaceIndex",`
"ServiceName"
Get-Ciminstance -ComputerName $Computer win32_NetworkAdapterConfiguration | select $Properties
#>
}

Function Get-LastPatchDate
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	Try
	{
		Out-Console -Type 1 -Message "Determining last patch date for $Computer"
		#$Session = [activator]::CreateInstance([type]::GetTypeFromProgID("Microsoft.Update.Session",$Computer))
		$Session = New-Object -ComObject Microsoft.Update.Session
		$Searcher = $Session.CreateUpdateSearcher()
		$HistoryCount = $Searcher.GetTotalHistoryCount()
		
		($Searcher.QueryHistory(0,1) | Where {$_.ResultCode -eq 2} | ForEach-Object {$_} | Sort Date -Desc | select Date -First 1).Date
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to determine last patch date for $Computer - $($_.Exception.Message)"
	}
}

Function Get-Patches
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain",
	#	$Days = '30')
	param([string]$Computer,
		$Days = 30)
		
	Try
	{
		Out-Console -Type 1 -Message "Gathering patch information for $Computer"
		$Date = $((Get-Date).AddDays(-$Days))
		#$Session = [activator]::CreateInstance([type]::GetTypeFromProgID("Microsoft.Update.Session",$Computer))
		$Session = New-Object -ComObject Microsoft.Update.Session
		$Searcher = $Session.CreateUpdateSearcher()
		$HistoryCount = $Searcher.GetTotalHistoryCount()
		
		$Properties = @{n='Status';e={
			Switch ($_.ResultCode)
			{
				0 {'Not Started'}
				1 {'In Progress'}
				2 {'Succeeded'}
				3 {'Succeeded With Errrors'}
				4 {'Failed'}
				5 {'Aborted'}
			}}},`
		@{n='KB';e={If($_.Title -Match "KB..\S+"){$Matches[0] -Replace '\W',''}}},`
		"ClientApplicationID",`
		"Date",`
		"Title",`
		"SupportURL"
		
		$Success = $Searcher.QueryHistory(0,$HistoryCount) | Where {$_.ResultCode -eq 2} | select $Properties
		$Failed = $Searcher.QueryHistory(0,$HistoryCount) | Where {$_.ResultCode -eq 4} | select $Properties
		
		$Titles = $Failed | select -expand Title -Unique
		$List = @()
		
		If ($Title)
		{
			#ForEach ($Title in $Titles)
			#{
			#	$List += ($Failed | where {$_.Title -eq $Title} | sort Date -desc)[0]
			#}
			
			ForEach ($Title in $Titles)
			{
				Try
				{
					$List.AddContent(($Failed | where {$_.Title -eq $Title} | sort Date -desc)[0])
				}
				Catch [System.Management.Automation.RuntimeException]
				{}
				Catch
				{DefaultCatch}
			}
			
			$RealFail = $List | Where {$Success -NotContains $_}
			$Result = $($Success + $RealFail) | Where {$_.Date -ge $Date} | Sort Date -Desc
		}
		Else
		{$Result = $Success | Where {[datetime]$_.Date -ge $Date} | Sort Date -Desc}
			
		If (!$Result){$Result = "No patches have been installed within the last $Days days"}
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get patch information for $Computer - $($_.Exception.Message)"
	}
	Return $Result
}

Function Get-ServiceStatus
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	$Properties = "DisplayName",`
		"Name",`
		@{n='Run As';e={$_.StartName}},`
		"StartMode",`
		"State"
	
	Try
	{
		If ($Computer = "$env:ComputerName.$env:UserDNSDomain")
		{
			$Properties = "DisplayName",`
				"Name",`
				@{n='Run As';e={$_.StartName}},`
				"StartMode",`
				"State"
		
			$Services = Get-WmiObject Win32_Service -Filter {State != 'Running' and StartMode = 'Auto'}
			$Result = ''
			foreach ($Service in $Services.Name)
			{
				$x = gp -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$Service" |
				? {$_.Start -eq 2 -and $_.DelayedAutoStart -ne 1} | Select Name
				If ($x)
				{$Result += $x | Select $Properties}
			}
			
			If (!$Result)
				{$Result = "All services set to Automatic Start Mode are running"}
		}
		
		Else
		{
			$Result = Invoke-Command -Computer $Computer
			{
				$Properties = "DisplayName",`
					"Name",`
					@{n='Run As';e={$_.StartName}},`
					"StartMode",`
					"State"
			
				$Services = Get-WmiObject Win32_Service -Filter {State != 'Running' and StartMode = 'Auto'}
				$Result = ''
				foreach ($Service in $Services.Name)
				{
					$x += gp -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$Service" |
					? {$_.Start -eq 2 -and $_.DelayedAutoStart -ne 1}
					If ($x)
					{$Result += $x | Select $Properties}
				}
				
				If (!$Result)
					{$Result = "All services set to Automatic Start Mode are running"}
			}
		}
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get service information for $Computer - $($_.Exception.Message)"
	}
		Return $Result
}

Function Get-ProcessInfo
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain",
	#[int]$Top = 10)
	param([string]$Computer,
		[int]$top = 10)

	$Properties = "Name",`
		"IDProcess",`
		@{n='% CPU Time';e={$_.PercentProcessorTime}},`
		@{n='PrivateMB';e={[long]("{0:N2}" -F $($_.PrivateBytes/1MB))}},`
		@{n='VirtualMB';e={[long]("{0:N2}" -F $($_.VirtualBytes/1GB))}},`
		@{n='Time (Min)';e={[int]("{0:N0}" -F ($_.ElapsedTime/60))}}
		
	$Properties = "Name",`
		"IDProcess",`
		@{n='% CPU Time';e={$_.PercentProcessorTime}},`
		@{n='PrivateBytes';e={[long]("{0:N0}" -F $($_.PrivateBytes))}},`
		@{n='VirtualBytes';e={[long]("{0:N0}" -F $($_.VirtualBytes))}},`
		@{n='Elapsed(hrs)';e={[int]("{0:N0}" -F ($_.ElapsedTime/3600))}}

	Try
	{
		Out-Console -Type 1 -Message "Gathering process information for $Computer"
		If ($PSVersionTable.PSVersion.Major -ge 3)
			{Get-CimInstance -ComputerName $Computer win32_PerfFormattedData_PerfProc_Process | ?{$_.Name -NotMatch "Idle|_Total"} | sort PercentProcessorTime -Desc | select $Properties -First $Top}
		ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
			{Get-WMIObject -ComputerName $Computer win32_PerfFormattedData_PerfProc_Process | ?{$_.Name -NotMatch "Idle|_Total"} | sort PercentProcessorTime -Desc | select $Properties -First $Top}
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to get process information for $Computer - $($_.Exception.Message)"
	}
}

Function Get-Uptime
{
	#param([string]$Computer = "$env:ComputerName.$env:UserDNSDomain")
	param([string]$Computer)
	
	If ($PSVersionTable.PSVersion.Major -ge 3)
		{$LastBootupTime = (Get-Ciminstance -ComputerName $Computer CIM_OperatingSystem).LastBootupTime}
	ElseIf ($PSVersionTable.PSVersion.Major -lt 3)
		{$LastBootupTime = (Get-WMIObject -ComputerName $Computer CIM_OperatingSystem | select @{n='LastBootupTime';e={$_.ConvertToDateTime($_.LastBootupTime)}}).LastBootupTime}
		
	$uptime = (Get-Date) - $LastBootUpTime
	If ($($Uptime.days) -le 1)
		{$Days = 'day'}
	Else {$Days = 'days'}
	If ($($Uptime.hours) -le 1)
		{$Hours = 'hour'}
	Else {$Hours = 'hours'}
	$Result = "$($Uptime.days) $Days, $($Uptime.hours) hours" 
	Return $Result
}

Function Get-DiskInfoTest
{
	$array = @()
	$diskdrives = get-wmiobject Win32_DiskDrive | sort Index

	$Disk = @()
	foreach ( $disk in $diskdrives )
	{
		$scsi_details = $('Port: ' + $disk.SCSIPort + ' Bus: ' + $disk.SCSIBus + ' Target: ' + $disk.SCSITargetID + ' LUN: ' + $disk.SCSILogicalUnit)

		write $( 'Disk ' + $disk.Index + ' - ' + $scsi_details + ' - ' + ( Get-HRSize $disk.size) )
		
		$pq = 'ASSOCIATORS OF {Win32_DiskDrive.DeviceID="' +
                      $disk.DeviceID.replace('\','\\') +
                      '"} WHERE AssocClass=Win32_DiskDriveToDiskPartition'
		
		$partitions = @( get-wmiobject -query $pq | sort StartingOffset )
		foreach ($partition in $partitions)
		{'ASSOCIATORS OF {Win32_DiskPartition.DeviceID="' +
                         $partition.DeviceID +
                         '"} WHERE AssocClass=Win32_LogicalDiskToPartition'
				$volumes = @(get-wmiobject -query $vq)

			write $( '    Partition ' + $partition.Index + '  ' + ( Get-HRSize $partition.Size) + '  ' + $partition.Type)

			foreach ( $volume in $volumes)
			{
				write $( '        ' + $volume.name + ' [' + $volume.FileSystem + '] ' + ( Get-HRSize $volume.Size ) + ' ( ' + ( Get-HRSize $volume.FreeSpace ) + ' free )')
			
				$Array += @(New-Object psobject -Property @{
					'DiskIndex' = $($disk.Index)
					'DiskAddress' = $('Port: ' + $disk.SCSIPort + ' Bus: ' + $disk.SCSIBus + ' Target: ' + $disk.SCSITargetID + ' LUN: ' + $disk.SCSILogicalUnit)
					'DiskSize' = $(Get-HRSize $disk.size)
					'ParIndex' = $($partition.Index)
					'ParSize' = $(Get-HRSize $partition.Size)
					'VolName' = $($volume.name)
					'VolFS' = $($volume.FileSystem)
					'VolSize' = $(Get-HRSize $volume.Size)
					'VolFree' = $(Get-HRSize $volume.FreeSpace)
				})
			} # end foreach vol
		} # end foreach part
		write ''
	} # end foreach disk
	Return $Array | Sort DiskIndex,ParIndex,VolName | Select DiskIndex,DiskAddress,DiskSize,ParIndex,ParSize,VolName,VolFS,VolSize,VolFree
}

Function Get-VMIPAddress
{
	Get-VM | Get-VMNetworkAdapter | Select VMName,@{n='IPAddresses';e={$_.IPAddresses -Match '\d{1,3}(\.\d{1,3}){3}'}} | ?{$_.IPAddresses -ne $Null}
}

Function Get-PSModulePath
{
	$env:PSModulePath -split ';'
}

Function Send-Mail
{
	[CmdletBinding(DefaultParameterSetName="None")]
	param(
	[parameter(Mandatory=$false)]
		[string[]]$Computer = "$env:ComputerName.$env:UserDNSDomain",
		
	[parameter(ParameterSetName='Mail',Mandatory=$True)]
		[string[]]$To,

	[parameter(ParameterSetName='Mail',Mandatory=$false)]
		[string]$From = "$env:ComputerName@$env:USERDNSDOMAIN",

	[parameter(ParameterSetName='Mail',Mandatory=$True)]
		[string]$SMTP,
	[parameter(ParameterSetName='Mail',Mandatory=$True)]
		[string[]]$Subject = "$Computer $subject - $($(Get-Date).ToString(""D""))",
	[parameter(ParameterSetName='Mail',Mandatory=$True)]
		[string[]]$Attachment
	)

	If(!$params.subject)
		{$params.subject = $subject}

	If(!$params.body)
		{$params.body = $body}
		
	If(!$params.from)
		{$params.from = $From}
	
	Try
	{
		If ($To.Count -gt 1)
		{
			$NewList = $Null
			foreach ($_ in $params.To) {$NewList += "$_,"}
			[string]$To = [String]$NewList.TrimEnd(",")
			$params.to = $To
		}
		
		Out-Console -Type 1 -Message "Sending message to $($params.To | Out-string), from $($params.from | Out-string) using SMTP server $($params.SMTP | Out-string)"

		$s = new-object System.Net.Mail.SmtpClient(($params.smtp))
		$a = new-object Net.Mail.Attachment($Attachment)
		$m = new-object System.Net.Mail.MailMessage
		$m.From = ($params.From )
		$m.IsBodyHTML = $true
		$m.To.Add($params.To)
		$m.Subject = ($params.subject)
		$m.body = gc $Attachment
		$m.Attachments.Add($a)
		$s.Send($m)

		$m.Dispose()
		$a.Dispose()
	
		Out-Console -Type 1 -Message "Successfully sent email to $To"
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to send message to $To - $($_.Exception.Message)"
	}
}

Function Start-Checks
{
	$Subject = "System Status Report"
	$Title = $Subject
	$frag = $Connectivity = $Array = @() 

	Test-OutputFile $Outfile
	
	ForEach ($Computer in $Params.Computers)
	{
		"Starting checks for $Computer" | out-file $log
		
		Out-Console -Type 1 -Message "Starting checks for $Computer"
		
		If (Test-Connectivity $Computer)
		{
			$Network = 'Online'
			
			If (Test-Connection -Computer 'google.com')
			{
				$Connectivity = @(New-Object psobject -Property @{
					'Network' = "<div class='success'>$Network"
					'Internet' = "<div class='success'>Internet Access Available"})
			}
			Else
			{
				$Connectivity = @(New-Object psobject -Property @{
					'Network' = "<div class='success'>$Network"
					'Internet' = "<div class='error'>No Internet Access"})
			}

			$TitlePage = "<p class=""ex2"">Red River Managed Services Team</p>"
			$TitlePage += "<p class=""ex4"">help@redriver.com</p>"
			$TitlePage += "<p class=""ex2"">System Health Status Report</p>"

			
			$frag = ConvertTo-HTML -Title $TitlePage -head $(Add-HTMLHeader)
			$frag += $TitlePage
			$frag += "<H2>$($Computer.ToUpper())</H2>"
			$frag += $Connectivity | Select Network,Internet | ConvertTo-HTML -as LIST -Pre "<H3>Connectivity</H3>" -Fragment
		"Gathering System Info data" | Out-file $log -Append
			$frag += Get-SystemInfo $Computer | ConvertTo-HTML -As LIST -Pre "<br><H3>System Info</H3>" -Fragment
		"nGathering OS Info data" | Out-file $log -Append
			$frag += Get-OSInfo $Computer | ConvertTo-HTML -As LIST -Pre "<br><H3>OS Info</H3>" -Fragment
		"Gathering Process Info data" | Out-file $log -Append
			$frag += Get-ProcessorInfo $Computer | ConvertTo-HTML -Pre "<br><H3>Processor Info</H3>" -Fragment
			$frag += If ($PSVersionTable.PSVersion.Major -ge 3){Get-CPUTemperature  | ConvertTo-HTML -Pre "<br><H3>CPU Temerature</H3>" -Fragment}
		"Gathering Memory Info data" | Out-file $log -Append
			$frag += Get-MemoryInfo $Computer | ConvertTo-HTML -Pre "<br><H3>Memory Info</H3>" -Fragment
		"Gathering Physical Memory Info data" | Out-file $log -Append
			$frag += Get-PhysicalMemoryInfo $Computer | ConvertTo-HTML -Pre "<br><H3>Physical Memory Info</H3>" -Fragment
		"Gathering SCSI Controller Info data"  | Out-file $log -Append
			$frag += Get-SCSIControllerInfo $Computer | ConvertTo-HTML -Pre "<br><H3>SCSI Controller Info</H3>" -Fragment
		"Gathering Disk Space data" | Out-file $log -Append
			$frag += Get-DiskSpace
		"Gathering Network Info data" | Out-file $log -Append
			$frag += Get-NetworkInfo $Computer | ConvertTo-HTML -Pre "<br><H3>NIC Info</H3>" -Fragment
		"Gathering Patch Info data"	 | Out-file $log -Append
			$Patches = Get-Patches  -Days $Days
				If ($Patches -match 'No patches')
					{$frag += ConvertTo-HTML -Pre "<br><H3>Patch History - Last $Days days</H3>" -Post "<p class=""ex0"">$Patches</p>"}
				Else {$frag += $Patches | ConvertTo-HTML -Pre "<br><H3>Patch History - Last $Days days</H3>" -Fragment}
			$Services = Get-ServiceStatus 
				If ($Services.GetType().name -eq 'string')
					{$frag += ConvertTo-HTML -Pre "<br><H3>Services set to autostart which are not running Info</H3>" -Post "<p class=""ex0"">$Services</p>" -Fragment}
				Else {$frag += Get-ServiceStatus  | ConvertTo-HTML -Pre "<br><H3>Services set to autostart which are not running Info</H3>" -Fragment}
		"Gathering Process Info data" | Out-file $log -Append
			$frag += Get-ProcessInfo $Computer -top $TopXProcesses | ConvertTo-HTML -Pre "<br><H3>Top $TopXProcesses Processes</H3>" -Fragment
			$frag += "<H3>$(Add-HTMLFooter)<H3>"
			$frag -replace '&lt;','<' -Replace '&gt;','>' -replace '&#39;',"'" -replace '<table>\r?\n</table>','' | Out-File $Outfile
		}
		Else
		{
			$Connectivity += @(New-Object psobject -Property @{
				'Network' = "<div class='error'>Unable to Connect to $Computer"})
			$frag += "unable to connect to $Computer - Network Status $NetworkStatus" | ConvertTo-HTML -Fragment
		}
	}
	
"Sending email" | Out-file $log -Append
	If ($Params.To -And $Params.SMTP)
	{
		Send-Mail -To $Params.To -From $Params.From -SMTP $Params.SMTP -Subject $Subject -Attachment $params.Outfile
	}
	
	#Undo-Variables
	Out-Console -Type 1 -Message "Completed checks for $Computer"
}
#endregion User Functions

#region Helper functions
function ConvertTo-LocalTime
{
	#Helper function to convert UTC time to local time
	param([String]$UTCTime)

	[System.TimeZoneInfo]::ConvertTimeFromUtc($UTCTime,[System.TimeZoneInfo]::FindSystemTimeZoneById((Get-CimInstance win32_timezone).StandardName))
}

function Get-HRSize
{
	#helper function to convert storage capacity inits
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True, ValueFromPipeline=$True)]
        [INT64] $bytes
    )
    process {
        if     ( $bytes -gt 1pb ) { "{0:N2} PB" -f ($bytes / 1pb) }
        elseif ( $bytes -gt 1tb ) { "{0:N2} TB" -f ($bytes / 1tb) }
        elseif ( $bytes -gt 1gb ) { "{0:N2} GB" -f ($bytes / 1gb) }
        elseif ( $bytes -gt 1mb ) { "{0:N2} MB" -f ($bytes / 1mb) }
        elseif ( $bytes -gt 1kb ) { "{0:N2} KB" -f ($bytes / 1kb) }
        else   { "{0:N} Bytes" -f $bytes }
    }
} # End Function:Get-HRSize

function Add-Gradient
{
	#Helper function to generate a graphical-like view of dispace space
	#This helper function is associated with the Get-DiskSapce function
	param([int]$i)
	
	$id = "bar" + $script:j++
	
	$c1=$c2=$c3=$c4=$c5=$c6=$c7=$c8=$c9=$c10=$c11=$c12=$c13=$c14=$c15=$c16=$c17=$c18=$c19=$c20='#ffffff'
	$Width = ''	
	Switch ($i)
	{
		{$i -lt 5}
			{
				$c1 = '#14AD33'
				$Width = '18.61vw'
			}		
		{$i -le 5 -And $i -lt 10}
			{
				$c1 = '#33CC33'; $c2 = '#38CF33'
				$Width = '17.6vw'
			}
		{$i -gt 10 -And $i -le 20}
			{
				$c1 = '#3DD133'; $c2 = '#42D433'; $c3 = '#47D633'; $c4 = '#4CD933'
				$Width = '15.6vw'
			}
		{$i -gt 20 -And $i -le 30}
			{
				$c1 = '#52DB33'; $c2 = '#57DE33'; $c3 = '#5CE033'; $c4 =  '#61E333'
				$c5 = '#66E633'; $c6 = '#6BE833'
				$Width = '13.6vw'
			}
		{$i -gt 30 -And $i -le 40}
			{
				$c1 = '#66FF33'; $c2 = '#6EFF30'; $c3 = '#75FF2E'; $c4 =  '#7DFF2B'
				$c5 = '#85FF29'; $c6 = '#8CFF26'; $c7 = '#94FF24'; $c8 =  '#9CFF21'
				$Width = '11.55vw'
			}
		{$i -gt 40 -And $i -le 50}
			{
				$c1 = '#99FF33'; $c2 = '#9EFF38'; $c3 = '#A3FF3D'; $c4 = '#A8FF42'
				$c5 = '#ADFF47'; $c6 = '#B2FF4C'; $c7 = '#B8FF52'; $c8 = '#BDFF57'
				$c9 = '#c7ff66'; $c10 = '#ccff33'
				$Width = '9.5vw'
			}
		{$i -gt 50 -And $i -le 60}
			{			  
				$c1 = '#CCFF33'; $c2 = '#CFFF30'; $c3 = '#D1FF2E'; $c4 = '#D4FF2B'
				$c5 = '#D6FF29'; $c6 = '#D9FF26'; $c7 = '#DBFF24'; $c8 = '#DEFF21'
				$c9 = '#E0FF1F'; $c10 = '#E3FF1C'; $c11 = '#E6FF1A'; $c12 = '#E8FF17'
				$Width = '7.5vw'
			}	
		{$i -gt 60 -And $i -le 70}
			{
				$c1 = '#FFDB12'; $c2 = '#FFD614'; $c3 = '#FFD117'; $c4 = '#FFCC1A'
				$c5 = '#FFC71C'; $c6 = '#FFC21F'; $c7 = '#FFBD21'; $c8 = '#FFB824'
				$c9 = '#FFB226'; $c10 = '#FFAD29'; $c11 = '#FFA82B'; $c12 = '#FFA32E'
				$c13 = '#FF9E30'; $c14 = '#FF9933'
				$Width = '5.5vw'
			}
		{$i -gt 70 -And $i -le 80}
			{			  
				$c1 = '#FF9933'; $c2 = '#FF9130'; $c3 = '#FF8A2E'; $c4 = '#FF822B'
				$c5 = '#FF7A29'; $c6 = '#FF7326'; $c7 = '#FF6B24'; $c8 = '#FF6321'
				$c9 = '#FF5C1F'; $c10 = '#FF541C'; $c11 = '#FF4C1A'; $c12 = '#FF4517'
				$c13 = '#FF3D14'; $c14 = '#FF3612'; $c15 = '#FF2E0F'; $c16 = '#FF260D'
				$Width = '3.4vw'
			}
		{$i -gt 80 -And $i -le 90}
			{		  
				$c1 = '#FA0000'; $c2 = '#F50000'; $c3 = '#F00000'; $c4 =  '#EB0000'
				$c5 = '#E60000'; $c6 = '#E00000'; $c7 = '#DB0000'; $c8 =  '#D60000'
				$c9 = '#D10000'; $c10 = '#CC0000'; $c11 = '#C70000'; $c12 =  '#C20000'
				$c13 = '#BD0000'; $c14 = '#B80000'; $c15 = '#B20000'; $c16 =  '#AD0000'
				$c17 = '#A80000'; $c18 = '#A30000'
				$Width = '1.4vw'
			}
		{$i -gt 90 -And $i -le 95}
			{		  
				$c1 = '#C93000'; $c2 = '#C72E00'; $c3 = '#C42B00'; $c4 = '#C22900'
				$c5 = '#BF2600'; $c6 = '#BD2400'; $c7 = '#BA2100'; $c8 = '#B81F00'
				$c9 = '#B51C00'; $c10 = '#B21A00'; $c11 = '#B01700'; $c12 = '#AD1400'
				$c13 = '#AB1200'; $c14 = '#A80F00'; $c15 = '#A60D00'; $c16 = '#A30A00'
				$c17 = '#A10800'; $c18 = '#9E0500'; $c19 = '#9C0300'
				$Width = '.35vw'
			}
		{$i -gt 95}
			{
				$c1 = '#C93000'; $c2 = '#C72E00'; $c3 = '#C42B00'; $c4 = '#C22900'
				$c5 = '#BF2600'; $c6 = '#BD2400'; $c7 = '#BA2100'; $c8 = '#B81F00'
				$c9 = '#B51C00'; $c10 = '#B21A00'; $c11 = '#B01700'; $c12 = '#AD1400'
				$c13 = '#AB1200'; $c14 = '#A80F00'; $c15 = '#A60D00'; $c16 = '#A30A00'
				$c17 = '#A10800'; $c18 = '#9E0500'; $c19 = '#9C0300'; $c20 = '#990000'
			}  
	}
		
	$Result = @("
      <table>
   		  <td bgcolor='$c1'; div style='width: .05vw'></td>
          <td bgcolor='$c2'; div style='width: .05vw'></td>
          <td bgcolor='$c3'; div style='width: .05vw'></td>
          <td bgcolor='$c4'; div style='width: .05vw'></td>
          <td bgcolor='$c5'; div style='width: .05vw'></td>
          <td bgcolor='$c6'; div style='width: .05vw'></td>
          <td bgcolor='$c7'; div style='width: .05vw'></td>
          <td bgcolor='$c8'; div style='width: .05vw'></td>
          <td bgcolor='$c9'; div style='width: .05vw'></td>
          <td bgcolor='$c10'; div style='width: .05vw'></td>
          <td bgcolor='$c11'; div style='width: .05vw'></td>
          <td bgcolor='$c12'; div style='width: .05vw'></td>
          <td bgcolor='$c13'; div style='width: .05vw'></td>
          <td bgcolor='$c14'; div style='width: .05vw'></td>
          <td bgcolor='$c15'; div style='width: .05vw'></td>
          <td bgcolor='$c16'; div style='width: .05vw'></td>
          <td bgcolor='$c17'; div style='width: .05vw'></td>
          <td bgcolor='$c18'; div style='width: .05vw'></td>
          <td bgcolor='$c19'; div style='width: .05vw'></td>
          <td bgcolor='$c20'; div style='width: .05vw'></td>
      </table>")
		
	Return $Result
}

function Add-HTMLColumn
{
	param(
		$data,
		$i
	)
	$Result = "<div class=""col=$i"">$data</div>"
	Return $Result
}

function Add-HTMLHeader
{
#helper function to define HTML header
$head = @"
</style> 
<Title>$Title</Title> 
<br> 
<style>
  .row::after
  {
		content: "";
		clear: both;
		display: table;
  }
  [class*="col-"]
  {
		float: left;
		padding: 15px;
  }
  .col-1 {width: 8.33%;}
  .col-2 {width: 16.66%;}
  .col-3 {width: 25%;}
  .col-4 {width: 33.33%;}
  .col-5 {width: 41.66%;}
  .col-6 {width: 50%;}
  .col-7 {width: 58.33%;}
  .col-8 {width: 66.66%;}
  .col-9 {width: 75%;}
  .col-10 {width: 83.33%;}
  .col-11 {width: 91.66%;}
  .col-12 {width: 100%;}

  table
  {
	font-size: 8pt;
	font-family: Segoe UI,Arial,sans-serif;
	border-width: 1px;
	border-style: solid;
	border-color: black;
	border-collapse: collapse;
	margin-right:auto;
	margin-left: 25px;
	class="center"
  }
  th
  {
	border-width: 1px;
	padding: 3px;
	border-style: solid;
	border-color: black;
	background-color: #B0C4DE;
  }
  td
  {
	border-width: 1px;
	padding: 3px;
	border-style: solid;
	border-color: black;
  }
  tr:first-child td, tr td:first-child
  {
    font-weight: bold;
  }
  div.first
  {
	padding-right: 20px;
	border-right: 1px grey solid;
  }
  div.second
  {
	margin-left: 30px;
	text-align: right;
  }
  $('td').filter(function () {
    return this.innerText.match(/^[-?0-9\s\.,]+$/);
  }).css('text-align', 'right');
p.ex0 {
	font-size: 8pt;
	font-family: Segoe UI,Arial,sans-serif;
	margin-left: 25px;
    }
p.ex1 {
    font: bold 30px "Lucida Sans", sans-serif;
    color: #660000;
    text-align: Right;
	}
p.ex2 {
    font: 20px "Lucida Sans", sans-serif;
    color: #660000;
    text-align: Right;
	}
p.ex3 {
    font: 15px "Lucida Sans", sans-serif;
    color: #660000;
    text-align: Right;
	}
p.ex4 {
    font: italic 12px "Lucida Sans", sans-serif;
    color: #660000;
    text-align: Right;
	margin-left: 25px;
	}
  H2 {
	-webkit-column-span: all; /* Chrome, Safari, Opera */
	column-span: all;
	color: #991970;
	padding: -1px;
	font-size: 18px;
   }
  H3 {
	counter-increment: section;
	content: ""Section "" counter(section) "". "";
	color: #991970;
	font-size: 12px;}
  H4 {
	-webkit-column-span: all; /* Chrome, Safari, Opera */
	color: #991970;
	font-size: 10px;
	line-height: 0%;}
  }
  .info {
	color: #00529B;
	background-color: #BDE5F8;
	font-weight: bold;
  }
  .success {
	color: #FFFFFF;
	background-color: #008000;
	font-weight: bold;
  }
  .warning {
	color: #FFFFFF;
	background-color: #DAA520;
	font-weight: bold;
  }
  .error {
	color: #FFFFFF;
	background-color: #FF0000;
	font-weight: bold;
  }
</style>
"@
Return $head
}

function Add-HTMLFooter
{
	#helper function to define HTML footer

	#$footer = ("<br><I>Report run {0} by {1}\{2}<I>" -f (Get-Date -displayhint date),$env:userdomain,$env:username)
	
	$Delim = '&#149;'
	$footer = "<i>21 Water Street <font color=""#891D36"">$Delim</font> Suite 500 <font color=""#891D36"">$Delim</font> Claremont, NH <font color=""#891D36"">$Delim</font> 03743 <font color=""#891D36"">$Delim</font> 603-448-8880 <font color=""#891D36"">$Delim</font> Fax 603-448-8844</I>"
	$footer += "$Delim</i>www.redriver.com</i>"
	$footer += ("<br><I>Report run {0} by {1}\{2}<I>" -f (Get-Date -displayhint date),$env:userdomain,$env:username,$env:ComputerName.$env:UserDNSDomain)

	Return $Footer
}

function Add-HTMLTableColor
{
	#Helper function to colorize HTML table cells and rows
	<#
    #Create the HTML table without alternating rows, colorize Warning and Error messages, highlighting the whole row.
        $eventTable = $events | New-HTMLTable -setAlternating $false |
            Add-HTMLTableColor -Argument "Warning" -Column "EntryType" -AttrValue "background-color:#FFCC66;" -WholeRow |
            Add-HTMLTableColor -Argument "Error" -Column "EntryType" -AttrValue "background-color:#FFCC99;" -WholeRow

	HTML Colors
	Success		Green	#00cc00
	Warning		Orange	#ff9900
	Error		Red		#ff3300
	Information	Blue	#66b3ff
	
	.EXAMPLE
		 Add-HTMLTableColor -Argument "OK" -Column "Status" -AttrValue "background-color:#00cc00;"
		 
    #>


    [CmdletBinding()] 
    param ( 
        [Parameter( Mandatory=$true,  
                ValueFromPipeline=$true,
                ValueFromPipelineByPropertyName=$false)]  
        [string]$HTML,
        
        [Parameter( Mandatory=$false, 
                    ValueFromPipeline=$false)]
        [String]$Column="Name",
        
        [Parameter( Mandatory=$false,
                    ValueFromPipeline=$false)]
        $Argument=0,
        
        [Parameter( ValueFromPipeline=$false)]
        [ScriptBlock]$ScriptBlock = {[string]$args[0] -eq [string]$args[1]},
        
        [Parameter( ValueFromPipeline=$false)]
        [String]$Attr = "style",
        
        [Parameter( Mandatory=$true, 
                    ValueFromPipeline=$false)] 
        [String]$AttrValue,
        
        [Parameter( Mandatory=$false, 
                    ValueFromPipeline=$false)] 
        [switch]$WholeRow=$false

        )
    
        add-type -AssemblyName System.xml.linq | out-null
        $xml = [System.Xml.Linq.XDocument]::Parse($HTML)   
        try
		{ 
            $columnIndex = (($xml.Descendants("th") | Where-Object { $_.Value -eq $Column }).NodesBeforeSelf() | Measure-Object).Count 
        }
        catch 
		{ 
            Try
			{
                $columnIndex = (($xml.Descendants("{http://www.w3.org/1999/xhtml}th") | Where-Object { $_.Value -eq $Column }).NodesBeforeSelf() | Measure-Object).Count
            }
            Catch
			{
                Throw "Error:  Namespace incorrect."
            }
        }

        if($columnIndex -as [double] -ge 0)
		{
            switch($xml.Descendants("td") | Where { ($_.NodesBeforeSelf() | Measure).Count -eq $columnIndex })
            {
                {$(Invoke-Command $ScriptBlock -ArgumentList @($_.Value, $Argument))} 
				{ 
                    
                    #mark the whole row or just a cell depending on param
                    if ($WholeRow)
					{ 
                        $_.Parent.SetAttributeValue($Attr, $AttrValue) 
                    } 
                    else
					{ 
                        $_.SetAttributeValue($Attr, $AttrValue) 
                    }
                }
            }
        }
        $xml.Document.ToString() 
}

function Get-MyVariables
{
	#Helper function to remove variables created within this module
	param([switch][bool]$Remove = $False)
	
	$Results = Get-Variable | Where-Object { $DefaultVariables -notcontains $_.Name }
	
	If ($Remove)
	{
		Try
		{
			$Results = $Results | % { Remove-Variable -Name "$($_.Name)" -Force -Scope "global"}
			#What to catch for error
			#$error[0].Exception.GetType().FullName
		}
		Catch [System.Management.Automation.ItemNotFoundException]
		{
			If (!($_.Exception_ -eq "Cannot find a variable with the name 'Remove'."))
				{"Unable to remove variable $_.ItemName"}
		}
	}
	Return $Results
	Remove-Variable Remove
}

function DefaultCatch
{
	param($_)
		write-host "Catch exception: $($_.Exception.GetType().FullName)" -foregroundcolor yellow
		write-host "Message:`t $($_.Exception.Message)" -foregroundcolor yellow
		$Line = $_.Exception.ErrorRecord.InvocationInfo.ScriptLineNumber
		$char = $_.Exception.ErrorRecord.InvocationInfo.OffsetInLine
		If ($line)
			{write-Host "At line: $line, char: $char" -foregroundcolor yellow}
}

function Out-Console
{
	#Helper function to output notifications to the console
    param( 
        [byte]$Type=1,
        [string]$Message
    )

    $TimeStamp = Get-Date -Format "dd.MMM.yyyy HH:mm:ss"
    $Time = Get-Date -Format "HH:mm:ss"

	Switch ($Type)
	{
		0 {Write-Host "[ERROR]   - $Time - $Message" -ForegroundColor Red}
		1 {Write-Host "[INFO]    - $Time - $Message" -ForegroundColor Green}
		2 {Write-Host "[WARNING] - $Time - $Message" -ForegroundColor Yellow}
		Default {Write-Host "[UNKNOWN] - $Time - $Message" -ForegroundColor Gray}
	}
}
#endregion Helper functions

#Upon loading the script, dynamically build parameter list
	$Params = @{}

	If($Computers)
	{$Params.Computers = $Computers}

	If ($Outfile)
	{$Params.Outfile = $Outfile}

	If ($To)
	{$Params.To = $To}

	If ($From)
	{$Params.From = $From}

	If ($SMTP)
	{$Params.SMTP = $SMTP}

	If ($Days)
	{$Params.Days = $Days}

	If ($Company)
	{$Params.Company = $Company}

	If ($TopXProcesses)
	{$Params.TopXProcesses = $TopXProcesses}

#Then start the function Start-Checks
	Start-Checks @Params
