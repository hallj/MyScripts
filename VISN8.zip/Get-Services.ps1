<#
.SYNOPSIS
	Gets the status of Windows services

.DESCRIPTION
	Gets the status of Windows services
	Also reads the service registry value to determine if the service is set to
	"Delayed Start" and/or "Trigger Start"

.PARAMETER
	ComputerName [string[]]
		Gets the services running on the specified computers. The default is the local computer.

		Type the NetBIOS name, an IP address, or a fully qualified domain name (FQDN) of a remote computer.
		To specify the local computer, type the computer name, a dot (.), or localhost.

		This parameter does not rely on Windows PowerShell remoting.
		You can use the ComputerName parameter of Get-Service even if your computer is not configured to run remote commands.

.PARAMETER
	StartType [string[]]
		Specifies the value for the service Start Mode.
		
		This parameter excepts multiple values.
		
		The accepted values are:
			Automatic
			Automatic (Delayed Start)
			Automatic (Delayed Start, Trigger Start)
			Automatic (Trigger Start)
			Boot
			Disabled
			Manual
			Manual (Trigger Start)
			Manual (Delayed Start, Trigger Start)
			System
		
		Values with spaces need to be enclosed in either single or double quotes
		
.PARAMETER
	Status [string[]]
		Specifies the value for the state.
		
		This parameter excepts multiple values.
		
		The accepted values are:
			ContinuePending
			Paused
			PausePending
			Running
			StartPending
			Stopped
			StopPending

.PARAMETER
	Exclude [string[]]
		Specifies one or service names to exclude from the results
		
		This parameter excepts multiple values.
			
.PARAMETER
	To [string[]]
		Specifies 1 or mail receipients.
		
		This parameter excepts multiple values.
		
		An email will be sent if specified criteria is met
		
.PARAMETER
	From [string]
		Specifies the address of the sending account.
		
		An email will be sent if specified criteria is met

.PARAMETER
	SMTP [string]
		Specifies the Fully Qualified Domain Name (FQDN) of the sending SMTP server
		
		TCP port 25 is used to communicate email
		
.PARAMETER
	Body [string[]]
		Specifies a multi-string value used as the main part of an email message 
	
.PARAMETER
	Attachment [string[]]
		 Specified one or more files which will be attached to the mail message, and
		 send to the mail recipient(s)
		 
		 This feature is currently disabled in this script
	
.PARAMETER
	HTML [Switch]
		Specifies a boolian (true/false) value to indicate if the mail message should
		use HTML formatting.
		
		HTML provides formatting and semantic markup capabilities that are not available
		with plain text
		
.PARAMETER
	SendMail [Switch]
		Specifies a boolian (true/false) value to indicate if the mail message should be
		sent if specified criteria is met
		
.PARAMETER
	AutoStart [Switch]
		Specifies a boolian (true/false) value to indicate if the Get-Services function
		should start automatically and run in a continuous loop

.PARAMETER
    <CommonParameters>
        This cmdlet supports the common parameters: Verbose, Debug,
        ErrorAction, ErrorVariable, WarningAction, WarningVariable,
        OutBuffer, PipelineVariable, and OutVariable. For more information, see
        about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

.EXAMPLE
	C:\PS>Get-Services.ps1
		Gets the services and their status on the local host
		
.EXAMPLE		
	C:\PS>Get-Services.ps1 -ComputerName computer1
		Gets the services and their status for the specified remote host
		
.EXAMPLE	
	C:\PS>Get-Services.ps1 -ComputerName computer1,Computer2
		Gets the services and their status for the specified remote hosts
		
.EXAMPLE	
	C:\PS>Get-Services.ps1 -StartType Automatic
		Retrieves a list of all services on the local computer where the start type is "Automatic"
		
.EXAMPLE	
	C:\PS>Get-Services.ps1 -StartType Automatic -Status Stopped
		Retrieves a list of all services on the local computer where the start type is "Automatic" 
		and the state is "Stopped"
		
.EXAMPLE	
	C:\PS>Get-Services.ps1 -StartType Automatic -Status Stopped,StartPending
		Retrieves a list of all services on the local computer where the start type is "Automatic"
		and the state is "Stopped" or "StopPending"
		
.EXAMPLE	
	C:\PS>Get-Services.ps1 -StartType Automatic,'Automatic (Delayed Start)' -Status Stopped,StopPending
		Retrieves a list of all services on the local computer where the start type is "Automatic" or
		"Automatic (Delayed Start)" and the state is "Stopped" or "StopPending"
		
.EXAMPLE	
	C:\PS>Get-Services.ps1 -ComputerName computer1 -StartType Automatic,'Automatic (Delayed Start)' 
						   -Status Stopped,StopPending -SendMail -To help@domain.com -SMTP smtp-server@domain.com
						   
		Retrieves a list of all services on the remote computer where the start type is "Automatic" or
		"Automatic (Delayed Start)" and the state is "Stopped" or "StopPending" and then sends an email
		to the specified recipient using the specified SMTP server.
		
		The default values for the sender, subject and body are used
		
		The default body is the results from the Get-services result
		
.EXAMPLE	
	C:\PS>Get-Services.ps1 -StartType Automatic,'Automatic (Delayed Start)' -Status Stopped,StopPending
						   -SendMail -To help@domain.com -From server.name@domain.com -SMTP mtp-server@domain.com 
						   -Subject 'Service Status'
		
		Retrieves a list of all services on the local computer where the start type is "Automatic" or
		"Automatic (Delayed Start)" and the state is "Stopped" or "StopPending" and then sends an email
		to the specified recipient from the specified sender using the specified SMTP server with the
		speciied subject.
		
		The default value for the body is used
		
		The default body is the results from the Get-services result
		
.EXAMPLE	
	C:\PS>Get-Services.ps1 -StartType Automatic -Status ContinuePending,Paused,PausePending,StartPending,
						   Stopped,StopPending -SendMail -To help@domain.com -From server.name@domain.com
						   -SMTP mtp-server@domain.com -Subject 'Service Status'
		
		Retrieves a list of all services on the local computer where the start type is "Automatic" and the
		state is "ContinuePending", "Paused", "PausePending", "StartPending", "Stopped", "StopPending"
		and then sends an email	to the specified recipient from the specified sender using the specified SMTP
		server with the speciied subject.
		
		This is equivalent to retieving a list of all services set to start automatically but are in the stopped state
		
		The default value for the body is used
		
		The default body is the results from the Get-services result
		
		This is the command that could be used as a shceduled task to alert the receipents of failed services

.INPUTS
    System.String
	System.Int32


.OUTPUTS
    System.String

.NOTES

	Script Name:	Get-Services.ps1
	Version:		1.0
	Created By:		Jon Hall
	Date Created:	September 20, 2017
	Date Modified:	
	Updates:		
					
	Requirements:	Powershell Version 2.0 or greater

.LINK
about_Modules
#>

Param
(
	[string[]]$ComputerName = $env:COMPUTERNAME,
	[string[]]$StartType,
	[string[]]$Status,
	[string[]]$Exclude,
	[string[]]$To,
	[string]$From,
	[string]$SMTP,
	[string]$Subject,
	[string[]]$Body,
	[string[]]$Attachment,
	[Switch]$HTML = $False,
	[Switch]$SendMail = $False,
	[switch]$AutoStart = $True
)
	
Function Get-Services
{
	[CmdletBinding(DefaultParameterSetName='Default')]
	Param
    (
	
		[Parameter(
			Mandatory = $false,
			ValueFromPipeline = $true, 
			ValueFromPipelineByPropertyName = $true,
			HelpMessage = 'Enter a Computer name or IP Address, accepts multiple ComputerNames'
		)]
		[string[]]$ComputerName = $env:COMPUTERNAME,
	
	
		[parameter(
			Mandatory = $false,
			ValueFromPipeline = $true, 
			ValueFromPipelineByPropertyName = $true,
			HelpMessage = 'Select 1 or more Service Startmodes'
		)]
		[ValidateSet(
			'Automatic',
			'Automatic (Delayed Start)',
			'Automatic (Delayed Start, Trigger Start)',
			'Automatic (Trigger Start)',
			'Boot',
			'Disabled',
			'Manual',
			'Manual (Trigger Start)',
			'Manual (Delayed Start, Trigger Start)',
			'System'
		)]
		[string[]]$StartType,
	
		[parameter(
			Mandatory = $false,
			ValueFromPipeline = $true, 
			ValueFromPipelineByPropertyName = $true,
			HelpMessage = 'Select 1 or more Service name to exclude'
		)]
		[string[]]$Exclude,
		
		[parameter(
			Mandatory = $false,
			ValueFromPipeline = $true, 
			ValueFromPipelineByPropertyName = $true,
			HelpMessage = 'Select 1 or more Service States'
		)]
		[ValidateSet(
			'ContinuePending',
			'Paused',
			'PausePending',
			'Running',
			'StartPending',
			'Stopped',
			'StopPending'
		)]
		[string[]]$Status,
		
		[parameter(
			ParameterSetName='Mail',
			Mandatory=$true
		)]
		[string[]]$To,

		[parameter(
			ParameterSetName='Mail',
			Mandatory=$false
		)]
		[string]$From = "$env:ComputerName@$env:USERDNSDOMAIN",

		[parameter(
			ParameterSetName='Mail',
			Mandatory=$true
		)]
		[string]$SMTP,
		
		[parameter(
			ParameterSetName='Mail',
			Mandatory=$false
		)]
		[string]$Subject = "$Computer $subject - $($(Get-Date).ToString(""D""))",
		
		[parameter(
			ParameterSetName='Mail',
			Mandatory=$false
		)]
		[string[]]$Body,
	
		[parameter(
			ParameterSetName='Mail',
			Mandatory=$false
		)]
		[string[]]$Attachment,
		
		[parameter(
			ParameterSetName='Mail',
			Mandatory=$false
		)]
		[Switch]$HTML = $False,
		
		[parameter(
			ParameterSetName='Mail',
			Mandatory=$false
		)]
		[Switch]$SendMail = $False,
		
		[parameter(
			Mandatory=$false
		)]
		[switch]$Loop = $True
	)
	
	$Properties = "DisplayName",`
		"Name",`
		@{n='Run As';e={$_.StartName}},`
		@{n='Start Mode';e={$StartMode}},`
		"State"

	If (!$($From.split('@')[1]))
		{$From = "$From" + "domain.com"}

	Do
	{
		Try
		{
			Out-Console -Type 1 -Message 'Generating a list of services'
			$Services = Get-WmiObject Win32_Service
			$Result = @()
			
			Out-Console -Type 1 -Message 'Determing if services are set to "Delayed Start" and/or "Trigger Start"'
			ForEach ($Service in $Services)
			{
				#$TriggerInfo = (gci -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$($Service.Name)").PSChildName -Match 'TriggerInfo'
				#The above command does not work with Powershell version 2.0
				
				#The below command does work
				$TriggerInfo = (gci -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$($Service.Name)" -ea SilentlyContinue | Select -expand PSChildName) -Match 'TriggerInfo'
				
				#$DelayedAutoStart = (gp -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$($Service.Name)" | gm).Name -Match 'DelayedAutoStart'
				#The above command does not work with Powershell version 2.0
				
				#The below command does work
				$DelayedAutoStart = (gp -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$($Service.Name)").DelayedAutoStart
				
				$Start = (gp -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$($Service.Name)").Start
				
				Switch ($Start)
				{
					0 {$Start = 'Boot'}
					1 {$Start = 'System'}
					2 {$Start = 'Automatic'}
					3 {$Start = 'Manual'}
					4 {$Start = 'Disabled'}
					Default {$Start = "Unknown"}
				}

				If ($TriggerInfo -And $DelayedAutoStart)
					{$StartMode = "$Start (Delayed Start, Trigger Start)"}
				ElseIf ($TriggerInfo)
					{$StartMode = "$Start (Trigger Start)"}
				ElseIf ($DelayedAutoStart)
					{$StartMode = "$Start (Delayed Start)"}
				Else
					{$StartMode = $Start}

				$Result += $Service | select $Properties
			}
		}
		Catch
		{
			#$_.Exception.Message
			$Message = "Catch exception: $($_.Exception.GetType().FullName)"
			$Message += "Message:`t $($_.Exception.Message)"
			$Line = $_.Exception.ErrorRecord.InvocationInfo.ScriptLineNumber
			$char = $_.Exception.ErrorRecord.InvocationInfo.OffsetInLine
			If ($line)
				{$Message += "At line: $line, char: $char"}
			Out-Console -Type 2 -Message $Message
		}
		
		If ($StartType -And $Status)
		{
			Out-Console -Type 1 -Message "Filtering services that match Start Mode $StartType and State $Status"
			$Result = $Result | ?{$StartType -Contains $_.'Start Mode' -And $Status -Match $_.State}
		}
		ElseIf ($StartType)
		{
			Out-Console -Type 1 -Message "Filtering services that match Start Mode $StartType"
			$Result = $Result | ?{$StartType -Contains $_.'Start Mode'}}
		ElseIf ($Status)
		{
			Out-Console -Type 1 -Message "Filtering services that match State $Status"
			$Result = $Result | ?{$Status -Match $_.State}
		}
		Else
		{$Result = $Result}
		
		$Result = $Result | ?{$Exclude -NotMatch $_.Name}
		
		If ($Result -And $SendMail)
		{
			ForEach ($R in $Result)
			{
				$Body = "Server name : $env:ComputerName"
				$Body += $R | fl | Out-string
				$Body += 'If this is a false-positive, edit the "Service Alerting" scheduled task on the server reporting the issue.'
				$Body += "`r`n"
				$Body += 'Select "Properties", select the "Actions" tab, and then edit the "Add arguments (optional)" field.'
				$Body += "`r`n"
				$Body += 'Locate the "-Exclude" parameter and add the service name as a comma-separated value.'
				$Body += "`r`n"
				$Body += 'If the "-Exclude" parameter does not exist add it to the command'
				$Body += "`r`n"
				$Body += 'Finally, end the task and then run it again.'
				$Body += "`r`n`r`n"
				$Body += 'Example:'
				$Body += "`r`n"
				$Body += "`t... C:\bin\Get-Services.ps1 -StartType Automatic -Status Stopped,StopPending -exclude TrustedInstaller -SendMail ..."
				
				Send-Mail -SMTP $SMTP -To $to -From $From -Subject "[WARNING] VISN8:$Computer - A service has stopped!" -Body $Body
			}
		}
		If (!$Result)
			{$Result = 'all services are running'}
		
		Out-Console -Type 1 -Message "Process complete"
		#Return $Result
		$Result
		
		Start-Sleep 300
	}
	Until ($Loop -eq $False)
}

function Out-Console
{
	#Helper function to output notifications to the console
    param( 
        [byte]$Type=1,
        [string]$Message
    )

    $TimeStamp = Get-Date -Format "dd.MMM.yyyy HH:mm:ss"
    $Time = Get-Date -Format "HH:mm:ss"

	Switch ($Type)
	{
		0 {Write-Host "[ERROR]   - $Time - $Message" -ForegroundColor Red}
		1 {Write-Host "[INFO]    - $Time - $Message" -ForegroundColor Green}
		2 {Write-Host "[WARNING] - $Time - $Message" -ForegroundColor Yellow}
		Default {Write-Host "[UNKNOWN] - $Time - $Message" -ForegroundColor Gray}
	}
}

Function Send-Mail
{
	[CmdletBinding(DefaultParameterSetName="None")]
	param(
	[parameter(
		Mandatory=$false)]
	[string[]]$ComputerName = "$env:ComputerName.$env:UserDNSDomain",
		
	[parameter(
		ParameterSetName='Mail',
		Mandatory=$True)]
	[string[]]$To,

	[parameter(
		ParameterSetName='Mail',
		Mandatory=$false)]
	[string]$From = "$env:ComputerName@$env:USERDNSDOMAIN",

	[parameter(
		ParameterSetName='Mail',
		Mandatory=$True)]
	[string]$SMTP,
	
	[parameter(
		ParameterSetName='Mail',
		Mandatory=$false)]
	[string]$Subject = "$ComputerName $subject - $($(Get-Date).ToString(""D""))",
	
	[parameter(
		ParameterSetName='Mail',
		Mandatory=$false)]
	[string[]]$Body,
	
	[parameter(
		ParameterSetName='Mail',
		Mandatory=$false)]
		[string[]]$Attachment,
		
	[parameter(
		ParameterSetName='Mail',
		Mandatory=$false)]
		[Switch]$HTML = $False
	)

	
	Try
	{
		If ($To.Count -gt 1)
		{
			$NewList = $Null
			foreach ($_ in $To) {$NewList += "$_,"}
			[string]$To = [String]$NewList.TrimEnd(",")
			$to = $To
		}
		
		Out-Console -Type 1 -Message "Sending message to $($To | Out-string) from $($from | Out-string) using SMTP server $($SMTP | Out-string)"

		$SmtpClient = new-object System.Net.Mail.SmtpClient($smtp)
		$MailMessage = new-object System.Net.Mail.MailMessage
		$MailMessage.From = $From
		If ($HTML)
		{
			$MailMessage.IsBodyHTML = $true
		}
		$MailMessage.To.Add($To)
		$MailMessage.Subject = $subject
		$MailMessage.body = $Body
<#
		If ($Attachment)
		{
			$Attach = new-object Net.Mail.Attachment($Attachment)
			$MailMessage.Attachments.Add($Attach)
		}
#>		
		$SmtpClient.Send($MailMessage)

		$MailMessage.Dispose()
		#$Attach.Dispose()
		
		Out-Console -Type 1 -Message "Successfully sent email to $To"
	}
	Catch
	{
		Out-Console -Type 0 -Message "Unable to send message to $To - $($_.Exception.Message)"
	}
}

If ($AutoStart -eq $True)
{
	#Dynamically build parameter list
	$Parameters = @{}
	
	If($ComputerName)
		{$Parameters.ComputerName = $ComputerName}

	If($StartType)
		{$Parameters.StartType = $StartType}
		
	If($Status)
		{$Parameters.Status = $Status}
		
	If($Exclude)
		{$Parameters.Exclude = $Exclude}
		
	If($To)
		{$Parameters.To = $To}
		
	If($From)
		{$Parameters.From = $From}
		
	If($SMTP)
		{$Parameters.SMTP = $SMTP}
		
	If($Subject)
		{$Parameters.Subject = $Subject}
		
	If($Body)
		{$Parameters.Body = $Body}
		
	If($Attachment)
		{$Parameters.Attachment = $Attachment}
		
	If($HTML)
		{$Parameters.HTML = $HTML}
		
	If($SendMail)
		{$Parameters.SendMail = $SendMail}

	#$Parameters
	
	#execute the function with the specified parameters
	Out-Console -Type 1 -Message "Starting Service Alerts"
	Get-Services @Parameters
}

